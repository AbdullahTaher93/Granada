package servlets;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;


public class JsonDecode {
	
	public static ArrayList<Product> getProducts() throws Exception{
		
		String queryUrl= "http://104.45.16.127:8080/DSS_P4/webapi/product";
		
		String output = Requests.sendGet(queryUrl);
		
		String newJson = "{ \n \"products\" : \n" + output + " \n }";
		
		System.out.println(newJson);
		
		final JSONObject obj = new JSONObject(newJson);
		
		final JSONArray productsArray= obj.getJSONArray("products");
		
		ArrayList<Product> products = new ArrayList<Product>();
		
		for(int i = 0; i< productsArray.length(); i++){
			
			JSONObject result = productsArray.getJSONObject(i);
			Product product = new Product();
			
			product.setProductId(result.getInt("productId"));
			product.setName(result.getString("name"));
			product.setDescription(result.getString("description"));
			product.setImageURL(result.getString("imageURL"));
			product.setOutstanding(result.getBoolean("outstanding"));
			product.setPrice(result.getFloat("price"));
			
			int departmentId = result.getJSONObject("department").getInt("departmentId");
			String departmentName = result.getJSONObject("department").getString("name");
			Department department = new Department(departmentName);
			department.setDepartmentId(departmentId);
			
			product.setDepartment(department);
			
			products.add(product);
		}
		
		/*System.out.println("La lista de productos es la siguiente:");
		System.out.println("--------------------------------------");
		for(Product p : products){
			System.out.println(p);
		}*/
		
		
		return products;
		
	}
	
	public static ArrayList<Product> getProductsDepartment(int departmentId) throws Exception{
		
		ArrayList<Product> products = new ArrayList<Product>();
		
		products = getProducts();
		
		ArrayList<Product> productsFilteredByDepartment = new ArrayList<Product>();
		
		for(int i = 0 ; i< products.size(); i++){
			
			if(products.get(i).getDepartment().getDepartmentId() == departmentId){
				productsFilteredByDepartment.add(products.get(i));
			}
		}
		
		return productsFilteredByDepartment;
		
	}
	
	public static int getLastShippingCartId() throws Exception{

		String queryUrl= "http://104.45.16.127:8080/DSS_P4/webapi/shippingCart";
		
		String output = Requests.sendGet(queryUrl);
		
		//output = output.substring(1,output.length()-1);
		
		String newJson = "{ \n \"carts\" : \n" + output + " \n }";
		
		final JSONObject obj = new JSONObject(newJson);
		
		final JSONArray cartsArray= obj.getJSONArray("carts");
		
		int lastCartId = 5000;
		
		for(int i = 0; i< cartsArray.length(); i++){
			
			JSONObject result = cartsArray.getJSONObject(i);
			lastCartId = result.getInt("cartId");
		}
		
		//final JSONObject obj = new JSONObject(output);
		
		//int cartId = obj.getInt("cartId");
		
		return lastCartId;
	}
	
	public static boolean addProductToCart(int cartId, int productId, int quantity) throws Exception{
		
		String queryURL = "http://104.45.16.127:8080/DSS_P4/webapi/shippingCart/"+ cartId + "/products";
		
		String jsonPut = " { \"cartId\" : "  + cartId + " , \"productId\" : " + productId + " , \"quantity\" : " + quantity + " } ";
		
		String output = Requests.sendPut(queryURL, jsonPut);

		if(output.contains("successfully")){
			return true;
		}
		else{
			return false;
		}	
	}
	
	public static Map<Product, Integer> getCartProducts(int cartId) throws Exception{
		
		// GET CAR PRODUCTS
		
		Map<Product,Integer> productsMap = new HashMap<Product,Integer>();
		
		String queryURL = "http://104.45.16.127:8080/DSS_P4/webapi/shippingCart/" + cartId + "/products";
		
		String output = Requests.sendGet(queryURL);
		
		String newJson = "{ \n \"products\" : \n" + output + " \n }";
		
		System.out.println(newJson);
		
		final JSONObject obj = new JSONObject(newJson);
		
		final JSONArray productsArray= obj.getJSONArray("products");
		
		ArrayList<Integer> productsId = new ArrayList<Integer>();
		ArrayList<Integer> quantity = new ArrayList<Integer>();
		
		for(int i = 0; i< productsArray.length(); i++){
			
			JSONObject result = productsArray.getJSONObject(i);
		
			productsId.add(result.getInt("productId"));
			quantity.add(result.getInt("quantity"));
		}
		
		// GET ALL PRODUCT
		
		ArrayList<Product> allProducts = new ArrayList<Product>();
		ArrayList<Product> cartProducts = new ArrayList<Product>();
		
		allProducts = getProducts();
		
		// GET OBJECTS CARTS PRODUCT
		
		int contador=0; // Iterador para el array de cantidad
		
		for(Integer i: productsId){
			for(int j = 0;j < allProducts.size(); j++){
				if(allProducts.get(j).getProductId() == i){
					//cartProducts.add(allProducts.get(j));
					productsMap.put(allProducts.get(j), quantity.get(contador));
					contador++;
				}
			}
		}
		
		return productsMap;
	}
	
	public static ArrayList<Department> getDepartments() throws Exception{
		
		ArrayList<Department> departments = new ArrayList<Department>();
		
		String queryURL = "http://104.45.16.127:8080/DSS_P4/webapi/department";
		
		String output = Requests.sendGet(queryURL);
		
		String newJson = "{ \n \"departments\" : \n" + output + " \n }";

		final JSONObject obj = new JSONObject(newJson);
		
		final JSONArray departmentsArray= obj.getJSONArray("departments");
		
		for(int i = 0; i< departmentsArray.length(); i++){
			
			JSONObject result = departmentsArray.getJSONObject(i);
			
			Department department = new Department(result.getString("name"));
			department.setDepartmentId(result.getInt("departmentId"));
			
			departments.add(department);
		}
		
		return departments;
		
	}
	
	
	public static void main(String [] args) throws Exception{
				
		Map<Product, Integer>cartProducts = new HashMap<Product, Integer>();
		cartProducts = getCartProducts(getLastShippingCartId());
		
		for(Map.Entry<Product, Integer> entry: cartProducts.entrySet()){
			System.out.println("Product -->" + entry.getKey() + "-- Quantity-->" + entry.getValue() );
		}
	}

}