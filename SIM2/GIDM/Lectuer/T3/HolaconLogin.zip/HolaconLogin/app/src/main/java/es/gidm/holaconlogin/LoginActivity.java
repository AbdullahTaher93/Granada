package es.gidm.holaconlogin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText usuario = (EditText) findViewById(R.id.usuario_edittext);
        final EditText password = (EditText) findViewById(R.id.password_edittext);
        final Button boton = (Button) findViewById(R.id.login_button);

        boton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (compruebaPassword(usuario.getText(), password.getText())) {
                    Intent holaAndroidIntent = new Intent(LoginActivity.this, HolaAndroid.class);
                    startActivity(holaAndroidIntent);
                } else {
                    usuario.setText("");
                    password.setText("");
                }
            }
        });

    }

    private boolean compruebaPassword(Editable usuario, Editable password){
        return (usuario.toString().equals("abad") && password.toString().equals("gidm"));
    }

    @Override
    protected void onRestart(){
        super.onRestart();
        final EditText usuario = (EditText) findViewById(R.id.usuario_edittext);
        final EditText password = (EditText) findViewById(R.id.password_edittext);

        usuario.setText("");
        password.setText("");
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.menu_login_screen, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }
}
