package es.gidm.localizamapa;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    private final String TAG = "LocalizaMapa";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(this,R.string.string_onCreate,Toast.LENGTH_SHORT).show();

        final EditText texto = findViewById(R.id.location);
        final Button boton = findViewById(R.id.map_button);

        boton.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String address = texto.getText().toString();
                    address = address.replace(' ', '+');
                    Intent geoIntent = new Intent(android.content.Intent.ACTION_VIEW,
                            Uri.parse("geo:0,0?q=" + address));
                    startActivity(geoIntent);
                } catch (Exception e) {
                    Log.e(TAG, e.toString());
                }
            }
        });
    }


    @Override
    protected void onStart(){
        super.onStart();
        Log.i(TAG, "La actividad es visible (onStart)");
        Toast.makeText(this,R.string.string_onStart,Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onRestart(){
        super.onRestart();
        Log.i(TAG, "La actividad se va a reiniciar (onRestart)");
        Toast.makeText(this,R.string.string_onRestart,Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.i(TAG, "La actividad es visible y está activa (onResume)");
        Toast.makeText(this,R.string.string_onResume, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.i(TAG, "La actividad deja de estar en primer plano (onPause)");
        Toast.makeText(this,R.string.string_onPause,Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.i(TAG, "La actividad ya no es visible (onStop)");
        Toast.makeText(this,R.string.string_onStop,Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.i(TAG, "La actividad va a ser destruida (onDestroy)");
        Toast.makeText(this,R.string.string_onDestroy,Toast.LENGTH_SHORT).show();
    }

}
