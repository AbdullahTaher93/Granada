package es.gidm.contactosenmapa;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String DATA_MIMETYPE = ContactsContract.Data.MIMETYPE;
    private static final Uri DATA_CONTENT_URI = ContactsContract.Data.CONTENT_URI;
    private static final String DATA_CONTACT_ID = ContactsContract.Data.CONTACT_ID;

    private static final String CONTACTS_ID = ContactsContract.Contacts._ID;
    private static final Uri CONTACTS_CONTENT_URI = ContactsContract.Contacts.CONTENT_URI;

    private static final String STRUCTURED_POSTAL_CONTENT_ITEM_TYPE =
            ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE;
    private static final String STRUCTURED_POSTAL_FORMATTED_ADDRESS =
            ContactsContract.CommonDataKinds.StructuredPostal.FORMATTED_ADDRESS;

    private static final int PICK_CONTACT_REQUEST = 0;
    static String TAG = "Contactos en Mapa";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i(TAG, (String) getText(R.string.string_onCreate));
        Toast.makeText(this,R.string.string_onCreate, Toast.LENGTH_SHORT).show();

        final Button boton = (Button) findViewById(R.id.boton);

        boton.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(Intent.ACTION_PICK, CONTACTS_CONTENT_URI);
                    startActivityForResult(intent, PICK_CONTACT_REQUEST);
                } catch (Exception e) {
                    //No hacer nada
                }
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK && requestCode == PICK_CONTACT_REQUEST) {

            ContentResolver cr = getContentResolver();
            Cursor cursor = cr.query(data.getData(), null, null, null, null);

            if (null != cursor && cursor.moveToFirst()) {
                String id = cursor.getString(cursor.getColumnIndex(CONTACTS_ID));
                String where = DATA_CONTACT_ID + " = ? AND " + DATA_MIMETYPE + " = ?";
                String[] whereParameters = new String[] { id, STRUCTURED_POSTAL_CONTENT_ITEM_TYPE };
                Cursor addrCur = cr.query(DATA_CONTENT_URI, null, where, whereParameters, null);

                if (null != addrCur && addrCur.moveToFirst()) {
                    String formattedAddress = addrCur.getString(addrCur
                            .getColumnIndex(STRUCTURED_POSTAL_FORMATTED_ADDRESS));

                    if (null != formattedAddress) {
                        formattedAddress = formattedAddress.replace(' ', '+');
                        Intent geoIntent = new Intent(android.content.Intent.ACTION_VIEW,
                                Uri.parse("geo:0,0?q=" + formattedAddress));
                        startActivity(geoIntent);
                    }
                }
                if (null != addrCur)
                    addrCur.close();
            }
            if (null != cursor)
                cursor.close();
        }
    }

    @Override
    protected void onRestart() {
        Log.i(TAG, (String) getText(R.string.string_onRestart));
        Toast.makeText(this,R.string.string_onRestart, Toast.LENGTH_SHORT).show();
        super.onRestart();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(TAG, (String) getText(R.string.string_onStart));
        Toast.makeText(this,R.string.string_onStart, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG, (String) getText(R.string.string_onResume));
        Toast.makeText(this,R.string.string_onResume, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG, (String) getText(R.string.string_onPause));
        Toast.makeText(this,R.string.string_onPause, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG, (String) getText(R.string.string_onStop));
        Toast.makeText(this,R.string.string_onStop, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, (String) getText(R.string.string_onDestroy));
        Toast.makeText(this,R.string.string_onDestroy, Toast.LENGTH_SHORT).show();
    }

}
