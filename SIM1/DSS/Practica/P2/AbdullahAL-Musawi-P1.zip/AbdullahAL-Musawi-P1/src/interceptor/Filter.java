package interceptor;

public interface Filter {
	public double Exe(Object o);
}
